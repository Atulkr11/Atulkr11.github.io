<?php
$balance = 100;
echo '<pre>';
var_dump($balance);
echo '</pre>';
$message = 'Insufficient balance';
echo '<pre>';
var_dump($message);
echo '</pre>';