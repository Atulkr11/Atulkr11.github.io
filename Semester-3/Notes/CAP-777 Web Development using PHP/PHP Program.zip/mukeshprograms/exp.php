<?php
    $a = 10;
    $b = 10.8;
    echo "Sum of $a and $b is ", $a + $b;
    echo "<br>";
    echo "Sub of $a and $b is ", $a - $b;