<!DOCTYPE html>
<html>
<body>
<?php
echo(rand(10, 20));
?>
</body>
</html>