<?php
// Create the timestamp for a particular date
// mktime(hour, minute, second, month, day, year)
echo mktime(15, 20, 12, 5, 10, 2014);
?>