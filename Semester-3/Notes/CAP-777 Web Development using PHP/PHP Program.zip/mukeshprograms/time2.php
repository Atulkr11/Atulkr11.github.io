<?php
$timestamp = 1660548684;
echo(date("F d, Y h:i:s", $timestamp));
?>