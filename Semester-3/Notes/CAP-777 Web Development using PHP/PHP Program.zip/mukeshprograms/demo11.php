define("ONE", "first thing");
print "<br>";
define("TWO2", "second thing");
print "<br>";
define("THREE_3", "third thing");
print "<br>";
define("__THREE__", "third value");
print "<br>";
// Invalid constant names
define("2TWO", "second thing");