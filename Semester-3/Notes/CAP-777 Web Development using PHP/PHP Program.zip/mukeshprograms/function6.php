<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Passing Arguments by Reference</title>
</head>
<body>
<?php
// Defining function
function test()
{
    $greet = "Hello World!";
    echo $greet;
}
test(); // Outputs: Hello World!
echo $greet; // Generate undefined variable error
?>
</body>
</html>