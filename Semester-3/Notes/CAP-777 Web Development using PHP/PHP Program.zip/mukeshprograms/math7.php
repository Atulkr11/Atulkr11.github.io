<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Get Ceil and Floor Value of a Number</title>
</head>
<body>

<?php
// Round fractions up
echo ceil(4.2) . "<br>";    // 0utputs: 5
echo ceil(9.99) . "<br>";   // 0utputs: 10
echo ceil(-5.18) . "<br>";  // 0utputs: -5
 
// Round fractions down
echo floor(4.2) . "<br>";    // 0utputs: 4
echo floor(9.99) . "<br>";   // 0utputs: 9
echo floor(-5.18) . "<br>";  // 0utputs: -6
?>

</body>
</html>