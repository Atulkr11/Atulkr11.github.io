<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Multidimensional Array</title>
</head>
<body>
<?php
$contacts = array(
    array(
        "name" => "Peter Parker",
        "email" => "peterparker@mail.com",
    ),
    array(
        "name" => "Clark Kent",
        "email" => "clarkkent@mail.com",
    ),
    array(
        "name" => "Harry Potter",
        "email" => "harrypotter@mail.com",
    )
);
echo "Peter Parker's Email-id is: " . $contacts[0]["email"];
?>

</body>
</html>