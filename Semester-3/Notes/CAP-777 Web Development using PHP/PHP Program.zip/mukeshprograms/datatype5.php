<?php
class greeting
{
    public $str = "Hello World!";
    function show_greeting()
    {
        return $this->str;
    }
}
$message = new greeting;
$message1 = new greeting;
var_dump($message);
var_dump($message1);
?>

