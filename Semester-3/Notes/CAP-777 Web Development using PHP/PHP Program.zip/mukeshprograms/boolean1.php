<?php
if (NULL)
print("This will always print<br>");

else
print("This will never print<br>");
?>