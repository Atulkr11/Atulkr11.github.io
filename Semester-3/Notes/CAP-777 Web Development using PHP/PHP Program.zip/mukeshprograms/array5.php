<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Associative Array</title>
</head>
<body>

<?php
$ages["Peter"] = "22";
$ages["Clark"] = "32";
$ages["John"] = "28";

// Printing array structure
print_r($ages); 
?>

</body>
</html>