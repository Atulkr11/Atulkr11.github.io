<?php
	const SALES_TAX = 2;
	$gross_price = 100;
	$net_price = $gross_price * (1 + SALES_TAX);
	echo $net_price; 
