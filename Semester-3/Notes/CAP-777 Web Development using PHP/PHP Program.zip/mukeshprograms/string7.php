<?php
$my_str = 'If the facts do not fit the theory, change the facts, facts, facts, facts.';
str_replace("facts", "truth", $my_str, $count);
echo "The text was replaced $count times.";
?>