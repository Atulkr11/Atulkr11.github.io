<?php
$my_numeric_string = '123';
var_dump($my_numeric_string);
echo "<br>";
$my_integer = (int)$my_numeric_string;
var_dump($my_integer);
?>
