<?php
$not_an_integer = 21 / 4;
var_dump($not_an_integer);
var_dump((int) (21 / 4)); 

?>
