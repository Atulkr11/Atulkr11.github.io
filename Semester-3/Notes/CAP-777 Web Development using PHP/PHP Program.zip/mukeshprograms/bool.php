<?php
echo '<pre>';
$is_email_valid = false;
var_dump($is_email_valid);
echo '</pre>';

echo '<pre>';
$is_submitted = true;
var_dump($is_submitted);
echo '</pre>';

$is_email_valid = true;
echo is_bool($is_email_valid);