<?php
// Get the weekday name of a particular date
echo date('l', mktime(0, 0, 0, 8, 15, 2022));
?>