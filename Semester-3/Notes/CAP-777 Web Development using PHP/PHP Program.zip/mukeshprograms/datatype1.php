<?php
$a = 'Hello world!';
var_dump($a);
echo "<br>";
echo $a;
echo "<br>";
 
$b = "Hello world!";
echo $b;
echo "<br>";
 
$c = 'Stay here, I\'ll be back.';
echo $c;
?>