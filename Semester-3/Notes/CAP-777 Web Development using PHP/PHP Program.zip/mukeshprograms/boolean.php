<?php

$x = FALSE;
$y = TRUE;
$z = TRUE;

echo $x;
print "<br>";
echo $y;
print "<br>";
echo $z;