function Input()
         {
           $open = fopen("php://STDIN", "r");
           $x = fgets($open);
           fclose($open);
           return $x;
         }