<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Arrays</title>
</head>
<body>

<?php
$color1 = "Red";
$color2 = "Green";
$color3 = "Blue";

echo $color1;
echo "<br>";

echo $color2;
echo "<br>";

echo $color3;
?>

</body>
</html>