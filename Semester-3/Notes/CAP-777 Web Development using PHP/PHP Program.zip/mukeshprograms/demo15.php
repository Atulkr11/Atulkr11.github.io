<html lang="en">
<head>
    <title>PHP Variables</title>
</head>
<body>
    <?php
        $title = 'PHP is awesome!';
    ?>
    <h1><?php echo $title; ?></h1>
    <h1><?= $title ?></h1>
</body>
</html>