<?php

$str = 'PHP scalar type';
$message = "PHP data types";
echo $str;
print "<br>";
echo $message;