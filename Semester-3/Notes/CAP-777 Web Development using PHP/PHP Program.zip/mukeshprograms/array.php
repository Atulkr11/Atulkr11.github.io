<?php
$carts = [ 'laptop', 'mouse', 'keyboard' ];
echo $carts[0]; // 'laptop'
print "<br>";
echo $carts[1]; // 'mouse'
print "<br>";
echo $carts[2]; // 'keyboard'