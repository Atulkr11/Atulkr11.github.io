<?php
$show_error = true;
var_dump($show_error);
?>