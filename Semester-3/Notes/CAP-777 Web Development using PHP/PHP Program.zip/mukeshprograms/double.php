<?php
   $many = 2.2888800;
   $many_2 = 2.2111200;
   $few = $many + $many_2;
   
   echo "$many + $many_2 = $few <br>";
?>