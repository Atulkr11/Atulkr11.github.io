<?php
$my_decimal = 42;
$my_binary = 0b101010;
$my_octal = 052;
$my_hexadecimal = 0x2a;
echo ($my_octal + $my_binary + $my_hexadecimal)
?>