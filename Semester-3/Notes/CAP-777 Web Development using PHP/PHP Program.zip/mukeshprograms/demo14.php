<?php

$total = 0;
$number = 1;

WHILE ($number <= 20) {
	$total += $number;
	$number++;
}

echo $total;