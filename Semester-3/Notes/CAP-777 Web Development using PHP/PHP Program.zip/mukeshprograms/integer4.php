<?php  
$x = "Mukesh";
var_dump($x);
?> 
