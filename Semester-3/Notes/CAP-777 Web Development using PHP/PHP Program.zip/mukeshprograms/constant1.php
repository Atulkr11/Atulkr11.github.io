<?php
   define("MINSIZE", 50);
   
   echo MINSIZE;
   echo "<br>";
   echo constant("MINSIZE"); // same thing as the previous line
?>