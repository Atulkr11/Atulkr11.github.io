<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Indexed Arrays</title>
</head>
<body>

<?php
$colors = array("Red", "Green", "Blue");

// Printing array structure
print_r($colors);
?>

</body>
</html>