$int_var = 12345;
$another_int = -12345 + 12345;