<?php
$my_str = 'You can do anything, but not everything';
echo strrev($my_str);
?>