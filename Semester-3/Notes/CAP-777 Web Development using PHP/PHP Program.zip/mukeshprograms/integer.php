<?php

$count = 0;
$max = 1000;
$page_size = 10;

echo $count;
print "<br>";
echo $max;
print "<br>";
echo $page_size;