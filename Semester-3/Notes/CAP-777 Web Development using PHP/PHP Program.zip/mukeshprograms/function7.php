<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Passing Arguments by Reference</title>
</head>
<body>
<?php
$greet = "Hello World!";
 
// Defining function
function test()
{
    echo $greet;
}
test();  // Generate undefined variable error
echo $greet; // Outputs: Hello World!
?>
</body>
</html>