<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Indexed Arrays</title>
</head>
<body>

<?php
$colors[0] = "Red"; 
$colors[1] = "Green"; 
$colors[2] = "Blue";

// Printing array structure
print_r($colors); 
?>

</body>
</html>