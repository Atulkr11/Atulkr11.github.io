<?php

$title = 'PHP is awesome!';
require 'index.view.php';