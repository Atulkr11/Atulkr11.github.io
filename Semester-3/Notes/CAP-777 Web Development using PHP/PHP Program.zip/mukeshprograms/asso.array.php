<?php
$prices = ['laptop' => 1000, 'mouse' => 50, 'keyboard' => 120 ];
echo $prices['laptop']; // 1000
print "<br>";
echo $prices['mouse']; // 50
print "<br>";
echo $prices['keyboard']; // 120