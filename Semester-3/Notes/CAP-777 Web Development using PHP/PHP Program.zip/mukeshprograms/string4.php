<?php
$my_str = 'Welcome to Tutorial Republic';
echo strlen($my_str);
?>