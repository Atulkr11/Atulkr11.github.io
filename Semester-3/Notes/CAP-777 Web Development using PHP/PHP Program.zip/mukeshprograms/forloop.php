<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP foreach Loop</title>
</head>
<body>
<?php
$colors = array("Red", "Green", "Blue");
foreach($colors as $value)
{
    echo $value . "<br>";
}
?>
</body>
</html>