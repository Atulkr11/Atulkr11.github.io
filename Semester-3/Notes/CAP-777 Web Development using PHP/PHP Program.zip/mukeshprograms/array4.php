<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Associative Array</title>
</head>
<body>

<?php
$ages = array("Peter"=>22, "Clark"=>32, "John"=>28);

// Printing array structure
print_r($ages); 
?>

</body>
</html>