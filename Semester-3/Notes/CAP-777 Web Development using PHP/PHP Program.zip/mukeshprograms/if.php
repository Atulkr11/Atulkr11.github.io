<?php
$today = date("Y");
echo $today;
?>