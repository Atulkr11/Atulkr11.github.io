<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP View Array Structure</title>
</head>
<body>

<?php
// Define array
$cities = array("London", "Paris", "New York");
 
// Display the cities array
Print_r($cities);
print("<br>");
var_dump($cities);
?>

</body>
</html>