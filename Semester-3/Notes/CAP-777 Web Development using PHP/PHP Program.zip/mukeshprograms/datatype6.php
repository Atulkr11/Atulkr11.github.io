<?php
$a = NULL;
var_dump($a);
echo "<br>";
 
$b = "Hello World!";
var_dump($b);
echo "<br>";
$b = 10;
var_dump($b);
?>