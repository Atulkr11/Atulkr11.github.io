<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Function</title>
</head>
<body>

<?php
// Defining function
function whatIsToday()
{
    echo "Today is ".date('l', mktime(0,0,0,10,3,1975));
}
// Calling function
whatIsToday();
?>

</body>
</html>