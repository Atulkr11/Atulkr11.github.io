<?php
// Executed at March 05, 2014 07:19:18
$timestamp = time();
echo($timestamp);
?>