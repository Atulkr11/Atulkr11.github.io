<?php

$count = 0.987;
$max = 1230.99;
$page_size = 10;

echo $count;
print "<br>";
echo $max;
print "<br>";
echo $page_size;