<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sorting PHP Indexed Array in Descending Order</title>
</head>
<body>
<?php
$numbers = array(1, 2, 2.5, 4, 7, 10);
rsort($numbers);
print_r($numbers);
?>
</body>
</html>